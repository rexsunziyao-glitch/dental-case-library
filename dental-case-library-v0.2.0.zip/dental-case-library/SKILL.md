---
name: dental-case-library
description: Turn deidentified dental case photos into collectible artist flipbooks and a compact local bookshelf. Use for 病例书、牙医作品集、艺术融合病例排版、我的病例书柜, including repeat editions and style variants.
---

# Dental Case Library · 我的病例书柜

Use for personal collections and professional peer exchange. Default to a restrained editorial artist book, not a patient explanation or diagnostic report. Retain already accepted preferences; ask only for missing choices that affect this edition.

## Completion contract

The deliverable is an ART-FUSED artist book with a unified motif, varied compositions, protected clinical source pixels, and a compact bookshelf. A photo-per-page album, contact sheet, empty art settings or a proposal is NOT the finished deliverable. Do not restart discovery of the approved aesthetic on every invocation. Default: choose a restrained motif/style from the actual images, explain the choice briefly, and execute within authorization. Never enforce six photos; preserve all originals and select editorial spreads proportionately to case size, with transparent selection reasons.

Before execution check whether this host can visually inspect and edit images. A text-only model cannot perform visual selection or art fusion: explicitly report that capability gap and prepare transferable inputs, never quietly substitute an ordinary album. A schema and flipbook code alone do not reproduce the accepted appearance.

Import produces a PRIVATE DRAFT and does not add it to the bookshelf. After creating and checking actual art assets and original-core masks, use `python3 scripts/library.py finalize --output <library> --id <case-id>` to validate and archive the artist book. No art means no completed shelf entry.

Reuse an existing authorized Dental Case Library when compatible. Do not modify unrelated books or force merging another host's library. If the existing shelf uses a different format, supply a compatible new book for that shelf or explain that concrete integration step; do not force the user to redo selection or art direction simply because a template differs.

## Workflow

1. Inspect the authorized photo folder locally. Confirm visible identifiers are removed; metadata stripping alone is not deidentification. Never send identifiable patient data to a model, cloud, or public repository. Original files stay untouched. Record uncertain phases as `unknown`; do not infer treatment chronology, tooth numbers, diagnosis or materials from appearance.
2. Choose one motif for this book and a compatible style; see `references/art-direction.md`. Different books may use different styles. Vary composition across spreads while retaining the motif. Read `references/case.schema.json` for editable interfaces.
3. Create a separate output library with `python3 scripts/library.py init --output <local-library>`. Import an authorized deidentified case with `python3 scripts/library.py import --output <local-library> --photos <folder> --id case-001 --title <title> --deidentified`. JPEG import removes metadata losslessly. The flag is a human assertion, not automated face/identifier detection. PNG/WebP need local sanitized JPEG exports first.
4. Edit `books/<id>/case.json`: theme, motif, stage, captions, original comparison pair, and spread layout. Read `references/art-direction.md` before generating art. Use the host's available image editing tool only within its authorization and payment rules. If no image tool exists, provide the exact prompt and protected-region instructions; do not pretend art was generated.
5. Blend the peripheral environment into artwork; never merely paste a complete rectangular photograph on a painting. Preserve clinical details by compositing source pixels over a protected opaque core. Prompts alone cannot guarantee pixel fidelity. Treat model output as peripheral art, inspect for duplicated teeth, ghost restorations, exaggerated gum tissue and implausible extensions. If a protected foreground creates a visible rectangle, repair the boundary rather than reducing fidelity of the core.
6. First develop one representative spread when the art direction is unresolved. Once the user accepts that direction, continue remaining spreads without repeatedly asking permission. Latest preferred aesthetic: less theatrical, fewer waves, no uncanny tissue extensions, original subject dominant. Do not claim every old generated page was approved.
7. Add local art paths and measured original placement/mask to `case.json`. Runtime supports left/right/center clinical placement, theme, image ratio and comparison. Import is only a draft; approved fusion assets are required for finalization. Native CSS gradients are not a substitute for requested AI fusion.
8. Start `python3 <local-library>/start.py --port 4194 --open`. Keep the local server alive while viewing; connection refused means it is stopped or on a different port. Opening a link does not start it. Books automatically enter the library index after successful finalization. Height follows photo count, thickness follows leaf count, bottom aligned and tightly packed.
9. Verify source preservation, metadata removal, phase uncertainty, image loading, flip navigation, original-view links, shelf entry and settings retention. Compare the exact protected source region against the composed image where feasible. Deliver local runnable paths and identify any untested host or unfinished art.

## Portability

Read `references/compatibility.md` for WorkBuddy and Doubao. This package is a tool-neutral instruction set plus a Python/HTML runtime, not a universal application plugin or executable SDK. Do not claim another host was tested without actually running it there. Public distribution contains code and synthetic fixtures only; never publish a user's case output.
