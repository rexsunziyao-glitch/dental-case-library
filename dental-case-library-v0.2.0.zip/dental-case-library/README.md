# Dental Case Library · 我的病例书柜

可重复调用的艺术牙科病例书 Skill，供个人收藏和同行交流。开源包不含真实患者照片或病例成品。代码 MIT；StPageFlip 保留独立 MIT 许可。艺术制作需要宿主图片编辑能力，导入和书柜运行只需 Python 3 及浏览器。

## 使用

支持 skills 的宿主导入此目录。Codex 可放到 ~/.codex/skills/dental-case-library。其他宿主见 references/compatibility.md；通用对话入口 PORTABLE_PROMPT.md。WorkBuddy、豆包尚未实测。

```sh
python3 scripts/library.py init --output ./my-library
python3 scripts/library.py import --output ./my-library --photos ./deidentified-jpegs --id case-001 --title '我的病例作品' --deidentified
python3 ./my-library/start.py --port 4194 --open
```

导入只建立草稿，不生成普通相册成品、不进入书柜。编辑 books/case-001/case.json，按 Skill 完成艺术融合和原图保护遮罩，然后运行 `python3 scripts/library.py finalize --output ./my-library --id case-001`，通过验证后归档。没有图像理解或编辑工具时，必须明确报告未完成艺术制作。不要固定限制六张照片。仅 JPEG；拒绝同名病例覆盖；原文件不变；移除 JPEG EXIF/XMP/IPTC/注释且保留色彩配置。脱敏是人工确认，不含自动识别或诊断。

开源仅上传此包，不上传 my-library 或其他病例目录。运行输出与许可独立，患者照片不因代码 MIT 而获得公开授权。
