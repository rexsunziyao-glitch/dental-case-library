import importlib.util, subprocess, sys, tempfile, unittest, json
from pathlib import Path
spec=importlib.util.spec_from_file_location('lib',Path(__file__).with_name('library.py'));lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
class Tests(unittest.TestCase):
 def test_metadata(self):
  raw=b'\xff\xd8'+b'\xff\xe1\x00\x08Exifxx'+b'\xff\xe2\x00\x05ICC'+b'\xff\xfe\x00\x06name'+b'\xff\xda\x00\x02scan\xff\xd9'
  self.assertEqual(lib.sanitize_jpeg(raw),b'\xff\xd8\xff\xe2\x00\x05ICC\xff\xda\x00\x02scan\xff\xd9')
  with self.assertRaises(ValueError):lib.sanitize_jpeg(b'notjpeg')
 def test_repeat_import(self):
  with tempfile.TemporaryDirectory() as t:
   root=Path(t);photos=root/'photos';photos.mkdir();raw=b'\xff\xd8\xff\xe1\x00\x08Exifxx\xff\xda\x00\x02scan\xff\xd9';(photos/'private-name.jpg').write_bytes(raw);output=root/'library';script=str(Path(__file__).with_name('library.py'))
   def run(*args):return subprocess.run([sys.executable,script,*args],capture_output=True)
   self.assertEqual(run('init','--output',str(output)).returncode,0)
   for id in ['case-001','case-002']:
    self.assertEqual(run('import','--output',str(output),'--photos',str(photos),'--id',id,'--title','Synthetic','--deidentified').returncode,0)
   self.assertEqual(len(json.loads((output/'books/library.json').read_text())),0)
   self.assertNotEqual(run('finalize','--output',str(output),'--id','case-001').returncode,0)
   case=output/'books/case-001';c=json.loads((case/'case.json').read_text());c['theme']['motif']='折光';(case/'art/background.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg"/>');(case/'art/mask.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg"/>');c['spreads']=[{'photoIndex':0,'artwork':'art/background.svg','originalMask':'art/mask.svg','original':{'x':0,'y':10,'width':60,'height':40}}];(case/'case.json').write_text(json.dumps(c));self.assertEqual(run('finalize','--output',str(output),'--id','case-001').returncode,0);self.assertEqual(len(json.loads((output/'books/library.json').read_text())),1)
   c['spreads'][0]['artwork']='../../../../not-local.svg';(case/'case.json').write_text(json.dumps(c));self.assertNotEqual(run('finalize','--output',str(output),'--id','case-001').returncode,0)
   self.assertNotEqual(run('import','--output',str(output),'--photos',str(photos),'--id','case-001','--title','Synthetic','--deidentified').returncode,0)
   self.assertEqual((photos/'private-name.jpg').read_bytes(),raw)
   self.assertNotIn('private-name',(output/'books/case-001/provenance.json').read_text())
   self.assertEqual(json.loads((output/'books/case-001/case.json').read_text())['photos'][0]['stage'],'unknown')
if __name__=='__main__':unittest.main()
