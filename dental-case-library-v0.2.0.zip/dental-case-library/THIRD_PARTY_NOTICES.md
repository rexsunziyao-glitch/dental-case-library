# Attribution

Workflow inspired by HaichaoLihc/create-photo-flipbook-ui (MIT, Copyright 2026 Haichao Li). Its original skill and project are not modified. Upstream MIT retained in LICENSE.

assets/runtime/vendor/page-flip.browser.js: StPageFlip, MIT, Copyright 2020 Nodlik; full license in vendor/PAGE-FLIP-LICENSE. No upstream third-party demo photography, 3D components, fonts, or clinical output is bundled.

New instructions, library scripts and runtime: MIT. User input and generated clinical artwork are not distributed and are not licensed by this code license.
