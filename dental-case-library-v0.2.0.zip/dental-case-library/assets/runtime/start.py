#!/usr/bin/env python3
"""Loopback-only static preview. No upload endpoints, cloud calls or directory listing."""
import argparse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit
import webbrowser
ROOT=Path(__file__).resolve().parent
PUBLIC={'shelf.css','shelf.js','index.html','reader.css','reader.js'}
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT),**kwargs)
    def send_head(self):
        path=unquote(urlsplit(self.path).path).lstrip('/') or 'index.html'
        host=self.headers.get('Host','')
        if host not in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}:
            self.send_error(403,'Local host only');return None
        if '..' in Path(path).parts or '\\' in path or not (path in PUBLIC or path.startswith(('books/','vendor/'))):
            self.send_error(404);return None
        target=(ROOT/path).resolve()
        if not target.is_relative_to(ROOT) or not target.is_file():
            self.send_error(404);return None
        return super().send_head()
    def end_headers(self):
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
        super().end_headers()
    def log_message(self,*args):
        pass
if __name__=='__main__':
    parser=argparse.ArgumentParser(description='我的病例作品书柜 · 本地启动')
    parser.add_argument('--port',type=int,default=4194)
    parser.add_argument('--open',action='store_true')
    args=parser.parse_args()
    try:
        with ThreadingHTTPServer(('127.0.0.1',args.port),Handler) as server:
            url=f'http://127.0.0.1:{args.port}/'
            print(f'我的病例作品书柜已启动：{url}\n保持这个窗口打开。按 Ctrl+C 停止。',flush=True)
            if args.open:webbrowser.open(url)
            server.serve_forever()
    except OSError as e:
        print(f'启动失败：{e}\n端口可能已占用。若已有书柜窗口，请直接打开它。')
        raise SystemExit(1)
    except KeyboardInterrupt:
        print('\n病例书柜已停止。')
