#!/usr/bin/env python3
"""Local-only library initializer and lossless JPEG metadata stripper."""
import argparse, hashlib, json, re, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sanitize_jpeg(data):
    if not data.startswith(b'\xff\xd8'): raise ValueError('Not JPEG')
    out=bytearray(data[:2]); i=2
    while i<len(data):
        start=i
        if data[i]!=255: raise ValueError('Malformed JPEG marker')
        while i<len(data) and data[i]==255:i+=1
        if i>=len(data):raise ValueError('Truncated JPEG')
        marker=data[i];i+=1
        if marker in (0xda,0xd9):out.extend(data[start:]);return bytes(out)
        if marker in range(0xd0,0xd8) or marker==1:out.extend(data[start:i]);continue
        if i+2>len(data):raise ValueError('Truncated JPEG length')
        n=int.from_bytes(data[i:i+2],'big')
        if n<2 or i+n>len(data):raise ValueError('Invalid JPEG length')
        payload=data[i+2:i+n]
        # Preserve ICC (APP2), JFIF (APP0); remove other application payloads and comments.
        if not (marker==0xfe or 0xe1<=marker<=0xef and marker!=0xe2):out.extend(data[start:i+n])
        i+=n
    raise ValueError('No JPEG scan')
def read_json(p):return json.loads(p.read_text(encoding='utf-8'))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='action',required=True)
    init=sub.add_parser('init');init.add_argument('--output',required=True)
    imp=sub.add_parser('import');imp.add_argument('--output',required=True);imp.add_argument('--photos',required=True);imp.add_argument('--id',required=True);imp.add_argument('--title',required=True);imp.add_argument('--deidentified',action='store_true')
    args=ap.parse_args();out=Path(args.output).resolve()
    if args.action=='init':
        if out.exists() and any(out.iterdir()):ap.error('Output must be empty; existing work is preserved')
        shutil.copytree(ROOT/'assets/runtime',out,dirs_exist_ok=True);(out/'books').mkdir();save(out/'books/library.json',[]);print(out);return
    if not args.deidentified:ap.error('Requires human confirmation: --deidentified')
    if not re.fullmatch(r'[a-z0-9][a-z0-9-]{0,63}',args.id):ap.error('Use a safe lowercase case ID')
    if not (out/'books/library.json').is_file():ap.error('Initialize library first')
    dest=out/'books'/args.id
    if dest.exists():ap.error('Case already exists; refusing overwrite')
    source=Path(args.photos).resolve();sources=sorted(f for f in source.iterdir() if f.is_file() and f.suffix.lower() in ('.jpg','.jpeg'))
    if not sources:ap.error('No JPEGs; sanitize/export other formats locally first')
    # Validate every input before writing any case output.
    stripped=[sanitize_jpeg(f.read_bytes()) for f in sources]
    dest.mkdir();(dest/'photos').mkdir();(dest/'art').mkdir();photos=[];manifest=[]
    for i,(f,data) in enumerate(zip(sources,stripped),1):
        name=f'photos/{i:03d}.jpg';(dest/name).write_bytes(data);photos.append({'file':name,'stage':'unknown','caption':f'影像 {i:02d}'});manifest.append({'file':name,'sourceSha256':hashlib.sha256(f.read_bytes()).hexdigest(),'outputSha256':hashlib.sha256(data).hexdigest()})
    c={'id':args.id,'title':args.title,'theme':{'motif':'待选择','style':'克制的摄影作品集','color':'#354b4c'},'imageFit':'contain','comparison':None,'photos':photos,'spreads':[]};save(dest/'case.json',c);save(dest/'provenance.json',manifest);shutil.copyfile(ROOT/'assets/runtime/reader.html',dest/'index.html')
    index=read_json(out/'books/library.json');index.append({'id':args.id,'title':args.title,'photoCount':len(photos),'pageCount':len(photos)+2,'color':c['theme']['color']});save(out/'books/library.json',index);print(dest)
if __name__=='__main__':main()
